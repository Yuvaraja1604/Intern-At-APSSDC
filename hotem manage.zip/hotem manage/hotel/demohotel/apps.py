from django.apps import AppConfig


class DemohotelConfig(AppConfig):
    name = 'demohotel'
