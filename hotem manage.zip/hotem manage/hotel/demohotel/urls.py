from django.urls import path
from . import views
from django.contrib.auth import views as ad

urlpatterns = [
    path('',views.start,name="ho"),
	path('hom',views.home,name="hm"),
	path('abt/',views.about,name="ab"),
    path('nxt/',views.next,name="nxt"),
    path('wi/',views.withd,name="with"),
    path('wil/',views.withlist,name="wili"),
    path('dl/<int:v>',views.dwl,name="dw"),
    path('lgn/',ad.LoginView.as_view(template_name="html/login.html"),name="log"),
	path('lgot/',ad.LogoutView.as_view(template_name="html/logout.html"),name="lgt"),
    path('ac/',views.acroom,name="acrr"),
    path('nac/',views.nacroom,name="nsac"),
    path('sac/',views.sacroom,name="sacr"),
    path('adm/',views.adm,name="li"),
    path('pop/<int:s>/',views.popu,name="po"),
    path('not/<int:s>/',views.adnot,name="no"),
	# path('usrlst/',views.userlist,name="usrl"),
    path('al/',views.alre,name="kt"),
    path('co/',views.com,name="com"),
    path('nor/',views.nor,name="nor"),
]