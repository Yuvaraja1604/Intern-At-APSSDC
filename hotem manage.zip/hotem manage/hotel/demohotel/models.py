from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
	g = [
		('0','--- Select Your Gender ---'),
		('1','Male'),
		('2','Female'),
	]
	c = [
		('0','ADMIN'),
		('1','USER'),
	]
	mble = models.CharField(max_length=10,null=True,blank=True)
	gdr = models.CharField(choices=g,default='0',max_length=5)
	role_type = models.CharField(choices=c,default='0',max_length=5)
	eid = models.CharField(max_length=10)

class Reg(models.Model):
	name=models.CharField(max_length=20)
	em=models.CharField(max_length=15)
	per=models.CharField(max_length=20)
	pay=models.IntegerField()
	wi=models.CharField(max_length=10)
	sa=models.CharField(max_length=10)



# Create your models here.
