from django.shortcuts import render,redirect
from django.core.mail import send_mail
from hotel import settings
from .models import Reg
from django.db.models import Sum

# Create your views here.
def start(request):
	return render(request,'html/start.html')
def home(request):
	return render(request,'html/home.html')

def about(request):
	return render(request,'html/about.html')
def next(request):
	if request.method =="POST":
		n=request.POST['r']
		if(n=="A/C ROOM"):
			return redirect('/ac')
		elif(n=="NON-A/C ROOM"):
			return redirect('/nac')
		elif(n=="SUPER DULUXEX"):
			return redirect('/sac')
	return render(request,'html/next.html')
def acroom(request):
	if request.method =="POST":
		n=request.POST['na']
		e=request.POST['ms']
		p=request.POST['ac']
		x=Reg.objects.create(name=n,em=e,per="A/C ROOM",pay=int(p))
	return render(request,'html/registera.html')
def nacroom(request):
	if request.method =="POST":
		n=request.POST['na']
		e=request.POST['ms']
		p=request.POST['ac']
		x=Reg.objects.create(name=n,em=e,per="NON- A/C ROOM",pay=int(p))
	return render(request,'html/registern.html')
def sacroom(request):
	if request.method =="POST":
		n=request.POST['na']
		e=request.POST['ms']
		p=request.POST['ac']
		x=Reg.objects.create(name=n,em=e,per="SUPER DULUXEX",pay=int(p))
	return render(request,'html/registers.html')
def withd(request):
	try:
		if request.method=="POST":
			w=request.POST['ac']
			x=Reg.objects.get(id=w)
			c=x.wi
			print(c)
			if(c!="withDrawl" and c!="Completed"):
				x.wi="withDrawl"
				x.save()
			elif(c=="withDrawl"):
				return redirect('/al')
			elif(c=="Completed"):
				return redirect('/co')
	except:
		return redirect('/nor')
	return render(request,'html/with.html')
def adm(request):
	h=Reg.objects.all()
	c=Reg.objects.filter(wi="withDrawl").count()
	n=Reg.objects.filter(per="NON- A/C ROOM").count()
	a=Reg.objects.filter(per="A/C ROOM").count()
	s=Reg.objects.filter(per="SUPER DULUXEX").count()
	x=Reg.objects.all().aggregate(Sum("pay"))
	t=x["pay__sum"]
	print(c)
	return render(request,'html/adm.html',{'z':h,'k':c,'c':t,'n':n,'a':a,'s':s})
def withlist(request):
	x=Reg.objects.all()
	return render(request,'html/withlist.html',{'z':x})
def dwl(request,v):
	c=Reg.objects.get(id=v)
	a=int(c.pay)//2
	n=c.name
	k=c.em
	t=settings.EMAIL_HOST_USER
	sbj='Room Registration : WithDrawl'
	m=f"Hello {n}\nSuccessfull Debited The Amount:{a} Rs TO Your Account Check Once !"
	b=send_mail(sbj,m,t,[k])
	c.pay=a
	c.save()
	c.wi="Completed"
	c.save()
	c.per=" "
	c.save()
	return redirect('/wil')
def popu(request,s):
	z=Reg.objects.get(id=s)
	n=z.name
	p=z.pay
	k=z.em
	r=z.per
	i=z.id
	print(k)
	t=settings.EMAIL_HOST_USER
	sbj='Room Registration : Payment Successfull'
	m=f"Hello {n}\n Your Payment for the following {r} is Successfull\n Amount : {p}\nYour Registration-ID:{i}"
	b=send_mail(sbj,m,t,[k])
	z.sa="Done"
	z.save()
	return redirect('/adm')
def alre(request):
	return render(request,'html/al.html')
def com(request):
	return render(request,'html/com.html')
def adnot(request,s):
	z=Reg.objects.get(id=s)
	n=z.name
	p=z.pay
	k=z.em
	r=z.per
	print(k)
	t=settings.EMAIL_HOST_USER
	sbj=f"Room Registration : Your {r} Is Not Avaliable"
	m=f"Hello {n}\n Your Amount : {p} Is Successfull Debited To Your Account\n check Once !"
	b=send_mail(sbj,m,t,[k])
	z.sa="Done"
	z.save()
	k=Reg.objects.get(id=s)
	k.pay=0
	k.save()
	k.wi="Completed"
	k.save()
	return redirect('/adm')
def nor(request):
	return render(request,'html/nor.html')